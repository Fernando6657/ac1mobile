package com.example.myapplicatio;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText editTitulo, editDiretor, editAno;
    RatingBar ratingNota;
    Spinner spinnerGenero, spinnerFiltroGenero;
    CheckBox checkCinema;
    Button btnSalvar;
    ListView listViewFilmes;

    com.example.myapplicatio.Banco banco;
    int filmeSelecionadoId = -1; // Para edição

    String[] generos = {"Ação", "Drama", "Comédia", "Ficção", "Terror"};

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicialização
        editTitulo = findViewById(R.id.editTitulo);
        editDiretor = findViewById(R.id.editDiretor);
        editAno = findViewById(R.id.editAno);
        ratingNota = findViewById(R.id.ratingNota);
        spinnerGenero = findViewById(R.id.spinnerGenero);
        spinnerFiltroGenero = findViewById(R.id.spinnerFiltroGenero);
        checkCinema = findViewById(R.id.checkCinema);
        btnSalvar = findViewById(R.id.btnSalvar);
        listViewFilmes = findViewById(R.id.listViewFilmes);

        banco = new com.example.myapplicatio.Banco(this);

        // Carregar spinners
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, generos);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerGenero.setAdapter(adapter);
        spinnerFiltroGenero.setAdapter(adapter);

        // Botão salvar
        btnSalvar.setOnClickListener(view -> salvarFilme());

        // Filtro por gênero
        spinnerFiltroGenero.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String generoSelecionado = generos[position];
                carregarLista(generoSelecionado);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        // Clique curto: editar
        listViewFilmes.setOnItemClickListener((parent, view, position, id) -> {
            Cursor cursor = (Cursor) listViewFilmes.getItemAtPosition(position);
            filmeSelecionadoId = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            editTitulo.setText(cursor.getString(cursor.getColumnIndexOrThrow("titulo")));
            editDiretor.setText(cursor.getString(cursor.getColumnIndexOrThrow("diretor")));
            editAno.setText(cursor.getString(cursor.getColumnIndexOrThrow("ano")));
            ratingNota.setRating(cursor.getFloat(cursor.getColumnIndexOrThrow("nota")));
            String genero = cursor.getString(cursor.getColumnIndexOrThrow("genero"));
            spinnerGenero.setSelection(getIndex(genero));
            checkCinema.setChecked(cursor.getInt(cursor.getColumnIndexOrThrow("viu_cinema")) == 1);
        });

        // Clique longo: excluir
        listViewFilmes.setOnItemLongClickListener((parent, view, position, id) -> {
            Cursor cursor = (Cursor) listViewFilmes.getItemAtPosition(position);
            int filmeId = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            banco.excluirFilme(filmeId);
            Toast.makeText(this, "Filme excluído", Toast.LENGTH_SHORT).show();
            carregarLista(spinnerFiltroGenero.getSelectedItem().toString());
            limparCampos();
            return true;
        });

        // Carregar lista inicial
        carregarLista(generos[0]);
    }

    private void salvarFilme() {
        String titulo = editTitulo.getText().toString();
        String diretor = editDiretor.getText().toString();
        int ano = Integer.parseInt(editAno.getText().toString());
        float nota = ratingNota.getRating();
        String genero = spinnerGenero.getSelectedItem().toString();
        boolean viuCinema = checkCinema.isChecked();

        if (filmeSelecionadoId == -1) {
            banco.inserirFilme(titulo, diretor, ano, nota, genero, viuCinema);
            Toast.makeText(this, "Filme salvo!", Toast.LENGTH_SHORT).show();
        } else {
            banco.atualizarFilme(filmeSelecionadoId, titulo, diretor, ano, nota, genero, viuCinema);
            Toast.makeText(this, "Filme atualizado!", Toast.LENGTH_SHORT).show();
            filmeSelecionadoId = -1;
        }

        carregarLista(spinnerFiltroGenero.getSelectedItem().toString());
        limparCampos();
    }

    private void carregarLista(String genero) {
        Cursor cursor = banco.listarPorGenero(genero);
        String[] campos = {"titulo", "ano", "nota", "genero"};
        int[] ids = {android.R.id.text1, android.R.id.text2};
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(this,
                android.R.layout.simple_list_item_2, cursor,
                new String[]{"titulo", "genero"}, new int[]{android.R.id.text1, android.R.id.text2},
                0);
        listViewFilmes.setAdapter(adapter);
    }

    private int getIndex(String genero) {
        for (int i = 0; i < generos.length; i++) {
            if (generos[i].equalsIgnoreCase(genero)) return i;
        }
        return 0;
    }

    private void limparCampos() {
        editTitulo.setText("");
        editDiretor.setText("");
        editAno.setText("");
        ratingNota.setRating(0);
        checkCinema.setChecked(false);
        spinnerGenero.setSelection(0);
    }
}
